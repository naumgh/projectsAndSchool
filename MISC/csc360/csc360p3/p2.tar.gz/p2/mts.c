#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <time.h>

struct timespec stop;
struct timespec start;

int load_time;
int cross_time;

//mutexes
pthread_mutex_t station;
pthread_mutex_t track;
pthread_cond_t isloaded;
pthread_cond_t crossing;

//Initialize mutex and convars




//struct holds train information
typedef struct train {
	pthread_cond_t * train_convar;
	int cross_time;
	int load_time;
	int prio;
	char *direction;
	int train_num;
} train;

//************************************//

//priority queues inspired by https://www.geeksforgeeks.org/priority-queue-using-linked-list/

typedef struct node {
	train * struct_data;
	int prio;
	struct node * next;
}node;

//stations
node * westStation;
node * eastStation;

node * createNode(train * struct_data){
	node * temp = (node*)malloc(sizeof(node));
	temp->struct_data = struct_data;
	temp->prio = struct_data->prio;
	temp->next = NULL;

}

train * peek(node** head){
	return (*head)->struct_data;
}

void pop(node ** head){
	node * temp = * head;
	(*head) = (*head)->next;
	free(temp);
}

int priorityPeek(node ** head){
	return (*head)->prio;
}

int isEmpty(node ** head){
	return (*head) == NULL;
}

void push(node ** head, train* struct_data){
	node* start = (*head);
	node * temp = createNode(struct_data);

	if(*head == NULL){
		*head = temp;
		return;
	}

	if((*head)->prio < temp->prio){
		temp->next = *head;
		(*head) = temp;
	}else if((*head)->struct_data->load_time == temp->struct_data->load_time && (*head)->struct_data->train_num > temp->struct_data->train_num){
		temp-> next = *head;
		(*head) = temp;
	}else{
		while(start->next != NULL && start->next->prio >= temp->prio){
			if(start->next->struct_data->load_time == temp->struct_data->load_time &&
			  start->next->struct_data->train_num > temp->struct_data->train_num){
				temp->next = start->next;
				start->next = temp;
				return;
			}
			start = start->next;
		}
		temp->next = start->next;
		start->next = temp;
	}

}

//******************************************************
int calculatePrio(char * direction){
	if(strcmp(direction, "W") == 0 || strcmp(direction, "E") == 0){
		return 1;
	}else{
		return 0;
	}
}

char* convertDirection(char * dir){
	char* direction;
	if(strcmp(dir, "e") == 0 || strcmp(dir, "E") == 0){
		direction = "East";
	}else{
		direction = "West";
	}
	return direction;
}


void populateStruct(char *direction, int loading_time, int crossing_time,int train_number, pthread_cond_t *train_convar, train trains[]){
	int prio = calculatePrio(direction);
	//printf("%d\n\n", prio);
	train t = {
		&train_convar[train_number],
		crossing_time,
		loading_time,
		prio,
		direction,
		train_number
	};
	trains[train_number] = t;
}

void outputTime(){
	
	if(clock_gettime(CLOCK_REALTIME, &stop) == -1){
		perror("failed to print time");
	}
	double accum = (stop.tv_sec - start.tv_sec) + (stop.tv_nsec - start.tv_nsec) / 1000000000.0;
	int min = (int)accum/60;
	int hour = (int)accum/3600;
	printf("%02d:%02d:%04.1f ", hour, min, accum);
}


void * loadingTrain(void *args){
	printf("%s\n", "loaded train");
	train * ptrtrain = (train*)args;
	unsigned int timeToLoad = (ptrtrain->load_time) * 100000;

	usleep(timeToLoad);
	outputTime();
	printf("Train %2d is ready to go %4s.\n",ptrtrain->train_num, convertDirection(ptrtrain->direction));
	pthread_mutex_lock(&station);

	if(ptrtrain->direction == "E" || ptrtrain->direction == "e"){
		push(&eastStation, ptrtrain);
	}else{
		push(&westStation, ptrtrain);
	}

	pthread_mutex_unlock(&station);
	pthread_cond_signal(&isloaded);
	pthread_cond_wait(ptrtrain->train_convar, &track);
	outputTime();
	printf("Train %2d is ON the main track going %4s\n", ptrtrain->train_num, convertDirection(ptrtrain->direction));
	unsigned int cross_time = (ptrtrain->cross_time) * 100000;
	usleep(cross_time);
	outputTime();
	printf("Traint %2d is OFF the main track going %4s\n",ptrtrain->train_num, convertDirection(ptrtrain->direction));
	pthread_mutex_unlock(&track);
	pthread_cond_signal(&crossing);
	pthread_cond_destroy(ptrtrain->train_convar);
	pthread_exit(0);
	

}

//timers
void startTimer(){
	struct timespec start;
	if(clock_gettime(CLOCK_REALTIME, &start) == 1){
		perror("failed to start time");
	}
}

void dispatchEast(){
	pthread_cond_signal(peek(&westStation)->train_convar);
	pthread_mutex_lock(&station);
	pop(&eastStation);
	pthread_mutex_unlock(&station);
	return;
}

void dispatchWest(){
	pthread_cond_signal(peek(&eastStation)->train_convar);
	pthread_mutex_lock(&station);
	pop(&westStation);
	pthread_mutex_unlock(&station);
	return;
}



int main(int argc, char * argv[]){
	//step1, open file
	pthread_mutex_init(&station, NULL);
	pthread_mutex_init(&track, NULL);
	pthread_cond_init(&crossing, NULL);
	pthread_cond_init(&isloaded, NULL);
		
	FILE * fp;
	char delim[] = " ";
	fp = fopen(argv[1],"r");
	int line = 0;
	int count = 0;
	train trains[count];
	char * temp_arr[3];
	int prev;
	char input[512];
	while(fgets(input, 512, fp)){
		int temp = 0;
		line++;
		printf("LINE:%d -> %s", line,input);
		char * ptr = strtok(input,delim);
		
		if(line > count){
		   count = line;
		}
		while(ptr != NULL){
			temp_arr[temp] = ptr; //we will use this array to populate prio queue
			ptr = strtok(NULL, delim);
			temp += 1;

		}
	
		pthread_cond_t conditions[556];
		for(int i = 0; i < 556; i++){
			pthread_cond_init(&conditions[count], NULL);
		}
			
		
		printf("%s",temp_arr[0]);
		printf("%s",temp_arr[1]);
		printf("%s",temp_arr[2]);
		
		sscanf(temp_arr[1], "%d", &load_time);
		sscanf(temp_arr[2], "%d", &cross_time);

		printf("%d", count-1);
		populateStruct(temp_arr[0], load_time, cross_time,count-1, conditions, trains);
	}

	//do something iwth a timer ??

	//create thread for threads
	pthread_t threads[count];
	for(int i = 0; i < count; i++){
		if(pthread_create(&threads[i], NULL, loadingTrain, (void*)&trains[i]) != 0){
			perror("couldn't create thread");
		}
	}

	//printf("%d\n", count);
	fclose(fp);

	prev = 1;	// signlas east
	while(count){
		pthread_mutex_lock(&track);
		pthread_cond_signal(&isloaded);

		if(isEmpty(&eastStation) && isEmpty(&westStation)){
			pthread_cond_wait(&isloaded, &track);
		}else if(isEmpty(&eastStation) && !(isEmpty(&westStation))){
			dispatchWest();
		}else if(!(isEmpty(&eastStation)) && isEmpty(&westStation)){
			dispatchEast();
		}else{
			if(priorityPeek(&eastStation) > priorityPeek(&westStation)){
				dispatchEast();
				prev = 1;
			}else if(priorityPeek(&eastStation) < priorityPeek(&westStation)){
				dispatchWest();
				prev = 0;
			}else if(prev == 1){
				dispatchWest();
			}else{
				dispatchEast();
			}
		}


	}

	pthread_cond_wait(&crossing, &track);
	pthread_mutex_unlock(&track);



	free(trains);
	pthread_mutex_destroy(&station);
	pthread_mutex_destroy(&track);
	pthread_cond_destroy(&crossing);
	pthread_cond_destroy(&isloaded);


}







































































































































































/*
pthread_mutex_t mutex1;
void * loadingTrain(void* arg){
	printf("train created\n");
}



typedef struct train{
	char* direction;
	int loading_time;
	int crossing_time;
	int train_number;
	pthread_cond_t *train_convar;

} train;

void populateStruct(char *direction, int loading_time, int crossing_time,int train_number, train trains[], pthread_cond_t *train_convar){
	train t = {
		direction,
		loading_time,
		crossing_time,
		train_number
	};

	trains[train_number] = t;
}




int main(int argc, char * argv[]){
	//step1, open file
	FILE * fp;
	char delim[] = " ";
	fp = fopen(argv[1],"r");
	int line = 0;
	int count = 0;
	train trains[count];
	char * temp_arr[3];
	int temp = 0;
	char input[512];
	while(fgets(input, 512, fp)){
		line++;
		printf("LINE:%d -> %s", line,input);
		char * ptr = strtok(input,delim);
		
		if(line > count){
		   count = line;
		}


		while(ptr != NULL){
			printf("%s\n", ptr);
			temp_arr[temp] = ptr;
			ptr = strtok(NULL, delim);
			temp += 1;

		}

		printf("%s ",temp_arr[0]);
		printf("%s ",temp_arr[1]);
		printf("%s",temp_arr[2]);
		int load_time;
		int cross_time;
		sscanf(temp_arr[1], "%d", &load_time);
		sscanf(temp_arr[2], "%d", &cross_time);
		pthread_t train_conditions[count];


		populateStruct(temp_arr[0], load_time, cross_time,count-1, trains);
		temp = 0;

		

	}

	printf("%d\n", count); 
	fclose(fp);

											//everything is populated, now it's time to create thread

	pthread_t threads[count];

	pthread_mutex_init(&mutex1, NULL);
	pthread_cond_init(&convar, NULL);
	for(int i = 0; i < count; i++){
		if(pthread_create(&threads[i], NULL, &loadingTrain, (void*)&trains[i]) != 0){
			perror("couldn't create thread");
		}
	}

	for(int i = 0; i < count; i++){
		if(pthread_join(threads[i], NULL) != 0){
			perror("couldn't join threads");
		}
	}
	pthread_mutex_destroy(&mutex1);
	pthread_cond_destroy(&convar);
	

	
	
	
	return 0;



}








	pthread_t train[count];
	pthread_mutex_init(&mutex1, NULL);

	for(int i = 0; i < count; i++){
		if (pthread_create(&train[i], NULL, &loadingTrain, NULL) != 0){
			perror("couldn't create thread");
		}	    
	}

	for(int i = 0; i < count; i++){
		if(pthread_join(train[i], NULL) != 0){
			perror("could not join thread");
		}
	}

	pthread_mutex_destroy(&mutex1);
	*/