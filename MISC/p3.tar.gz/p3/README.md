*I am assuming no subdirectories, as stated by Pan

type "make -f Makefile". Please ignore all warnings and run all parts as specified in the make file.
