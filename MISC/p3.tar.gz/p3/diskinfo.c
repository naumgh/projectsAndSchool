/*
Naum Hoffman
V00927502
P3
*/

#include <stdio.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>

//Super block
struct __attribute__((__packed__)) superblock_t{
    uint8_t  fs_id [8];
    uint16_t block_size;
    uint32_t file_system_block_count;
    uint32_t fat_start_block;
    uint32_t fat_block_count;
    uint32_t root_dir_start_block;
    uint32_t root_dir_block_count;
};

//time and date entry
struct __attribute__((__packed__)) dir_entry_timedate_t{
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;
};

//Directory entry
struct __attribute__((__packed__)) dir_entry_t{
    uint8_t status;
    uint32_t starting_block;
    uint32_t block_count;
    uint32_t size;
    struct dir_entry_timedate_t create_time;
    struct dir_entry_timedate_t modify_time;
    uint8_t filename[31];
    uint8_t unused[6];
};

void part_1(int argc, char** argv){
    int fd = open(argv[1], O_RDWR);
    struct stat buffer;
    int status = fstat(fd, &buffer);

    void* address=mmap(NULL, buffer.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    struct superblock_t* sb;
    sb=(struct superblock_t*)address;
    //printf("fs_id in struct: %s\n", sb->fs_id);
    printf("block size in struct: %d\n", htons(sb->block_size));
    printf("block count in struct: %d\n", htonl(sb->file_system_block_count));
    printf("fat block start in struct: %d\n", htonl(sb->fat_start_block));
    printf("fat block count in struct: %d\n", htonl(sb->fat_block_count));
    printf("Root directory start: %d\n", htonl(sb->root_dir_start_block));
    printf("Root directory blocks: %d\n", htonl(sb->root_dir_block_count));
    
    int start = htons(sb->block_size) * htonl(sb->fat_start_block);
    int end = htonl(sb->fat_block_count) * htons(sb->block_size);
    end = end + start;

    //printf("%d",end);

    int free_bloc;
    int reserve_bloc;
    int allo_bloc;
    //int end_file;


    for(int i = start; i < end; i += 4){
        int q;
        memcpy(&q,i+address,4);
        q = htonl(q);
        if(q == 0){
            free_bloc++;
        }else if(q == 1){
            reserve_bloc++;
        }else{
            allo_bloc++;
        }

    }
    
    printf("\n\nFAT information:\n");
    printf("Free Blocks: %d\n", free_bloc);
    printf("Reserved Blocks: %d\n", reserve_bloc);
    printf("Allocated Blocks: %d\n", allo_bloc);


    munmap(address,buffer.st_size);
    close(fd);
}

void part_2(int argc, char ** argv){
    int fd = open(argv[1], O_RDWR);
    //char * dir_name = &argv[2];

    struct stat buffer;
    int status = fstat(fd, &buffer);

    void* address=mmap(NULL, buffer.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    struct superblock_t* sb;
    sb=(struct superblock_t*)address;
    
    int block_size = htons(sb->block_size);
    int start = block_size * htonl(sb->root_dir_start_block);
    int end = start + (block_size * htonl(sb->root_dir_block_count));
    struct dir_entry_t* dir;

    //according to pan, subdirectories are not included, so there is only one possible case
    if(argc >= 3){
        printf("no subdirectories allowed, please re run\n");
    }else{
        //we look at all directory blocks and output
        for(int i = start; i<end; i+=64){
            dir = (struct dir_entry_t*) (address+i);
            int status = dir->status;
            int fsize = htonl(dir->size);
            unsigned char * fname = dir->filename;
            int month = dir->create_time.month;
            int year = htons(dir->create_time.year);
            int day = dir->create_time.day;
            int minute = dir->create_time.minute;
            int hour = dir->create_time.hour;
            int second = dir->create_time.second;

            if(status != 0){
                if(status == 3){
                    printf("%c", 'F');
                    printf("%10d", fsize);
                    printf("%30s ", fname);
                    printf("%02d/%02d/%02d ", year,month,day);
                    printf("%02d:%02d:%02d", hour,minute,second);
                    printf("\n");
                }else if(status==5){
                    printf("%c", 'D');
                    printf("%10d", fsize);
                    printf("%30s", fname);
                    printf("%02d/%02d/%02d ", year,month,day);
                    printf("%02d:%02d:%02d", hour,minute,second);
                    printf("\n"); 
                }
            }
       }

    }
    munmap(address,buffer.st_size);
    close(fd);
}



void part_3(int argc, char ** argv){
    int fd = open(argv[1], O_RDWR);
    //char * dir_name = &argv[2];

    struct stat buffer;
    int status = fstat(fd, &buffer);

    void* address=mmap(NULL, buffer.st_size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    struct superblock_t* sb;
    sb=(struct superblock_t*)address;
    
    int block_size = htons(sb->block_size);
    int start = block_size * htonl(sb->root_dir_start_block);
    int end = start + (block_size * htonl(sb->root_dir_block_count));
    struct dir_entry_t* dir;
    char* comparison;
    int check = 0;
    char * arg_name = argv[2];
    uint32_t i = 0;
    int dirs = 0;
    char * fpname;
    for(i = 0; i < strlen(arg_name); i++){
        if(arg_name[i] == '/'){
            break;
        }
    }

    fpname = malloc(strlen(arg_name) - i);
    strncpy(fpname, arg_name+i+1,strlen(arg_name)-i);

    printf("\n%s\n", fpname);

    FILE *new_file = fopen(argv[3], "wb");

    for(int i = start; i < end; i+=64){
        dir = (struct dir_entry_t*) (address+i);
        comparison = dir->filename;
        if(strcmp(comparison, fpname)!=0){
            continue;

        } else{
            check = 1;
            break;
        }

    }

    if(check == 0){
        perror("FILE NOT FOUND");
        exit(1);
    }

    
    


    



}


int main(int argc, char* argv[]) {
    #if defined(PART1)
        part_1(argc,argv);
    #elif defined(PART2)
        part_2(argc,argv);
    #elif defined(PART3)
        part_3(argc,argv);
    #else
    #    error "PART[123] must be defined"
    #endif
        return 0;
    
   
}

