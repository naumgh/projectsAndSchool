To run the code:
python3 SmartClient.py [address]

does not handle docs.uvic.ca